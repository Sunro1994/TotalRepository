package com.TravelMaker.controller.admin;

import com.TravelMaker.model.Recommend_TravelDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.TravelMaker.model.LodgeDTO;
import com.TravelMaker.service.admin.AdminService;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/Admin")
public class AdminController {
	
	@Autowired private AdminService adminService;
	
	// 관리자 페이지
	@GetMapping("/admin")
	public void admin() {}
	
	@GetMapping("/lodgeWrite")
	public void lodgeWrite() {}
	
	@PostMapping("/actionLodgeWrite")
	public String lodgeWrite(LodgeDTO dto) {
		int row = adminService.insertLodge(dto);
		System.out.println(row + "행이 추가되었습니다.");
		
		return "redirect:/Admin/admin";
	}

	@GetMapping("/recommendWrite")
	public void recommendWrite(){}

	@PostMapping("/recommendWrite")
	public String recommendWrite(Recommend_TravelDTO dto){
		int row = adminService.insertRecommend(dto);
		System.out.println(row + "행이 추가 되었습니다");

		return "redirect:/Admin/admin";
	}

	@GetMapping("/recommendDelete/{idx}")
	public String recommendDelete(@PathVariable ("idx") int idx){
		int row = adminService.deleteOneByIdx(idx);
		System.out.println(row + "행이 삭제 되었습니다.");

		return "redirect:/Admin/admin";
	}

	@GetMapping("/recommendModify/{idx}")
	public ModelAndView recommendModify(@PathVariable ("idx")int idx){
		ModelAndView mav = new ModelAndView("/Admin/recommendModify");
		mav.addObject("idx", idx);

		return mav;
	}

	@PostMapping("/recommendModify/{idx}")
	public String recommendModify(Recommend_TravelDTO dto){
		System.out.println(dto);
		int row = adminService.updateRecommend(dto);

		System.out.println(row + "행이 수정 되었습니다");

		return "redirect:/Admin/admin";
	}

}