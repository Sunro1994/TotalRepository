package com.TravelMaker.repository.admin;

import com.TravelMaker.model.LodgeDTO;

public interface AdminDAO {

	int insertLodge(LodgeDTO dto);

	
}
