package com.TravelMaker.service.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.TravelMaker.component.FileComponent;
import com.TravelMaker.model.LodgeDTO;
import com.TravelMaker.repository.admin.AdminDAO;

@Service
public class AdminService {
	
	@Autowired FileComponent fileComponent;
	@Autowired AdminDAO adminDAO;
	
	public int insertLodge(LodgeDTO dto) {
		String fileName = fileComponent.upload(dto.getImgFile());
		dto.setLodge_realimgname(fileName);
		int row = adminDAO.insertLodge(dto);
		
		return row;
	}

}
