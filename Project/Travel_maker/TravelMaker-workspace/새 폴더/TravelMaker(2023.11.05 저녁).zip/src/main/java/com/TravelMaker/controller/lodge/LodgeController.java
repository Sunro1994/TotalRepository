package com.TravelMaker.controller.lodge;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.TravelMaker.model.LodgeDTO;
import com.TravelMaker.model.Lodge_Room_TypeDTO;
import com.TravelMaker.model.Reserved_Lodge_Current_StateDTO;
import com.TravelMaker.model.TravelMaker_MemberDTO;
import com.TravelMaker.service.lodge.LodgeService;

	

@Controller
@RequestMapping("/lodge")
public class LodgeController {
	
	@Autowired private LodgeService lodgeService;
	
	@GetMapping("/lodge_main")
	public String lodge() {
		return "/Lodge/lodge";
	}
	
	@GetMapping("/LodgeRoom/{idx}")
	public ModelAndView lodgeRoom(@PathVariable("idx") int idx) {
		ModelAndView mav = new ModelAndView("/Lodge/lodgeRoom");
		
		List<Lodge_Room_TypeDTO> RoomList = lodgeService.getRoomList(idx);
		LodgeDTO lodgeDTO = lodgeService.getLodge(idx);
		mav.addObject("RoomList",RoomList);
		mav.addObject("lodgeDTO",lodgeDTO);
		
		
		return mav;
	}
	
	@GetMapping("/Payment/{idx}/{start}/{end}")
	public ModelAndView payment(@PathVariable("idx") int idx, @PathVariable("start")String start, @PathVariable("end") String end) {
		ModelAndView mav = new ModelAndView("/Lodge/payment");
//		System.out.println(start);
//		System.out.println(end);
		String[] startArr = start.split("-");
		String start1 = startArr[2];//년
		String start2 = startArr[0];//월
		String start3 = startArr[1];//일
		String startDate = start1 + "-" + start2 + "-" + start3;
		String[] endArr = end.split("-");
		String end1 = endArr[2];//년
		String end2 = endArr[0];//월
		String end3 = endArr[1];//일
		String endDate = end1 + "-" + end2 + "-" + end3;
		Lodge_Room_TypeDTO roomDTO = lodgeService.getOneRoom(idx);
		mav.addObject("roomDTO",roomDTO);
		mav.addObject("start", startDate);
		mav.addObject("end", endDate);
		return mav;
	}
	
	@GetMapping("/reservationCheck/{idx}/{start}/{end}")
	public ModelAndView reservationCheck(
			@PathVariable("idx") int idx, @PathVariable("start")String start, @PathVariable("end") String end, HttpSession session
			) throws ParseException {
		ModelAndView mav = new ModelAndView("/Lodge/reservationCheck");
//		Lodge_Room_TypeDTO roomDTO = lodgeService.getOneRoom(idx);
		TravelMaker_MemberDTO memberDTO = (TravelMaker_MemberDTO)session.getAttribute("user");
		Reserved_Lodge_Current_StateDTO ReservedDTO = new Reserved_Lodge_Current_StateDTO();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		
		Date startDate = sdf.parse(start);
		Date endDate = sdf.parse(end);
		ReservedDTO.setReserved_Lodge_Current_State_StartDate(startDate);
		ReservedDTO.setReserved_Lodge_Current_State_EndDate(endDate);
		ReservedDTO.setReserved_Lodge_Current_State_RoomIdx(idx);
		ReservedDTO.setReserved_Lodge_Current_State_UserId(memberDTO.getTravelMaker_Member_UserId());
		lodgeService.insertReserved(ReservedDTO);
		
//		mav.addObject("roomDTO",roomDTO);
//		mav.addObject("start", start);
//		mav.addObject("end", end);
//		mav.addObject("user", memberDTO);
		return mav;
	}
	
	@GetMapping("/review")
	public String review() {
		return "/Lodge/review";
	}
	
//	@PostMapping("/review")
//	public int reviewWrite(Lodge_ReviewDTO dto, HttpSession session) {
//		TravelMaker_MemberDTO user = (TravelMaker_MemberDTO)session.getAttribute("user");
//		int idx = user.getTravelMaker_Member_Idx();
//		Lodge_Room_TypeDTO t = lodgeService.selctOne(idx); // 정보가져오기
//		// 별점,닉네임,방이름,내용,숙간기간 
//		dto.setLodge_Review_Writer(user.getTravelMaker_Member_UserNickName()); // 닉네임
//		dto.setLodge_Room_Type_Name(t.getLodge_Room_Type_Name());	// 방이름		
//		dto.setLodge_review_date(t.getLodge_review_date());			// 숙박기간
//		int row = lodgeService.insertReview(dto );	// 쿼문으로 이동해서 가져올 함수
//		System.out.println(row != 0 ? "리뷰작성" : "리뷰작성실패");
//		return row;
//	}
}
