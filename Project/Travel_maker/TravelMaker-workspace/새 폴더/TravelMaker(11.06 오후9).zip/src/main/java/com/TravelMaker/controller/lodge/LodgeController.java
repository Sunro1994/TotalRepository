package com.TravelMaker.controller.lodge;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.TravelMaker.model.LodgeDTO;
import com.TravelMaker.model.Lodge_ReviewDTO;
import com.TravelMaker.model.Lodge_Room_TypeDTO;
import com.TravelMaker.model.Reserved_Lodge_Current_StateDTO;
import com.TravelMaker.model.SaveListDTO;
import com.TravelMaker.model.TravelMaker_MemberDTO;
import com.TravelMaker.service.lodge.LodgeService;

	

@Controller
@RequestMapping("/lodge")
public class LodgeController {
	
	@Autowired private LodgeService lodgeService;
	
	@GetMapping("/lodge_main")
	public String lodge() {
		return "/Lodge/lodge";
	}
	
	@GetMapping("/LodgeRoom/{idx}")
	public ModelAndView lodgeRoom(@PathVariable("idx") int idx) {
		ModelAndView mav = new ModelAndView("/Lodge/lodgeRoom");
		List<Lodge_Room_TypeDTO> roomList = lodgeService.getRoomList(idx);
		LodgeDTO lodgeDTO = lodgeService.getLodge(idx);
		
		List<Lodge_ReviewDTO> reviewList = lodgeService.getReviewList(idx);
		
		mav.addObject("RoomList",roomList);
		mav.addObject("lodgeDTO",lodgeDTO);
		mav.addObject("reviewList",reviewList);

		return mav;
	}
	
	@GetMapping("/Payment/{idx}/{start}/{end}")
	public ModelAndView payment(@PathVariable("idx") int idx, @PathVariable("start")String start, @PathVariable("end") String end) {
		ModelAndView mav = new ModelAndView("/Lodge/payment");
//		System.out.println(start);
//		System.out.println(end);
		String[] startArr = start.split("-");
		String start1 = startArr[2];//년
		String start2 = startArr[0];//월
		String start3 = startArr[1];//일
		String startDate = start1 + "-" + start2 + "-" + start3;
		String[] endArr = end.split("-");
		String end1 = endArr[2];//년
		String end2 = endArr[0];//월
		String end3 = endArr[1];//일
		String endDate = end1 + "-" + end2 + "-" + end3;
		Lodge_Room_TypeDTO roomDTO = lodgeService.getOneRoom(idx);
		mav.addObject("roomDTO",roomDTO);
		mav.addObject("start", startDate);
		mav.addObject("end", endDate);
		return mav;
	}
	
	@GetMapping("/reservationCheck/{idx}/{start}/{end}")
	public ModelAndView reservationCheck(
			@PathVariable("idx") int idx, @PathVariable("start")String start, @PathVariable("end") String end, HttpSession session
			) throws ParseException {
		ModelAndView mav = new ModelAndView("/Lodge/reservationCheck");
//		Lodge_Room_TypeDTO roomDTO = lodgeService.getOneRoom(idx);
		TravelMaker_MemberDTO memberDTO = (TravelMaker_MemberDTO)session.getAttribute("user");
		Reserved_Lodge_Current_StateDTO ReservedDTO = new Reserved_Lodge_Current_StateDTO();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		
		Date startDate = sdf.parse(start);
		Date endDate = sdf.parse(end);
		ReservedDTO.setReserved_Lodge_Current_State_StartDate(startDate);
		ReservedDTO.setReserved_Lodge_Current_State_EndDate(endDate);
		ReservedDTO.setReserved_Lodge_Current_State_RoomIdx(idx);
		ReservedDTO.setReserved_Lodge_Current_State_UserId(memberDTO.getTravelMaker_Member_UserId());
		lodgeService.insertReserved(ReservedDTO);
		
//		mav.addObject("roomDTO",roomDTO);
//		mav.addObject("start", start);
//		mav.addObject("end", end);
//		mav.addObject("user", memberDTO);
		return mav;
	}
	@GetMapping("/review/{lodge_idx}/{lodge_Room_Type_Idx}")
	public ModelAndView review(@PathVariable("lodge_idx") int lodge_idx,
						@PathVariable("lodge_Room_Type_Idx")int lodge_Room_Type_Idx
						){
		ModelAndView mav = new ModelAndView("/Lodge/review");
		
		//1. 리뷰쓴 후 이동을 위한 숙소 idx
		mav.addObject("lodge_idx",lodge_idx);
		
		//2. 숙소 객실 idx
		mav.addObject("lodge_Room_idx",lodge_Room_Type_Idx);
		
		
		
		
		
		return mav;
	}
	
	@PostMapping("/review/{lodge_idx}/{lodge_Room_Type_Idx}")
	public ModelAndView reviewWrite(Lodge_ReviewDTO dto, HttpSession session, String lodge_idx) {
		ModelAndView mav = new ModelAndView();
		//회원 가져오기
		TravelMaker_MemberDTO user = (TravelMaker_MemberDTO)session.getAttribute("user");
		// 삽입할 idx 추가
		int idx = user.getTravelMaker_Member_Idx();
		
		//이동할 숙소 객실 idx 출력 확인
		System.out.println("lodge_idx : "+lodge_idx);
		System.out.println(dto.getLodge_Review_RoomTypeIdx());
		dto.setLodge_Review_Writer(user.getTravelMaker_Member_UserId());		
		
		int row = lodgeService.insertReview(dto);
		System.out.println("row" + row);
		mav.setViewName("redirect:/lodge/LodgeRoom/"+lodge_idx);
		return mav;
	}
	
	@GetMapping("/heart/{lodge_idx}")
	public ModelAndView saveInsert(@PathVariable("lodge_idx") int lodge_idx , HttpSession session) {
		ModelAndView mav = new ModelAndView("redirect:/lodge/LodgeRoom/" + lodge_idx);
		TravelMaker_MemberDTO user = (TravelMaker_MemberDTO) session.getAttribute("user");
		
		SaveListDTO save = new SaveListDTO();
		save.setSaveList_Lodge_Idx(lodge_idx);
		save.setSaveList_UserId(user.getTravelMaker_Member_UserId());
		
		int row = lodgeService.saveInsert(save);
		
		if(row == 1) {
			System.out.println("완료");
		}
		else {
			System.out.println("실패");
		}
		return mav;
	}
}
