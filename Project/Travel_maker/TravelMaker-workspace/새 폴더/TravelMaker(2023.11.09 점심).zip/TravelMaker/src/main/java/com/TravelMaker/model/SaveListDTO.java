package com.TravelMaker.model;

public class SaveListDTO {

	private String saveList_UserId;
	private int saveList_Lodge_Idx;
	
	public String getSaveList_UserId() {
		return saveList_UserId;
	}
	public void setSaveList_UserId(String saveList_UserId) {
		this.saveList_UserId = saveList_UserId;
	}
	public int getSaveList_Lodge_Idx() {
		return saveList_Lodge_Idx;
	}
	public void setSaveList_Lodge_Idx(int saveList_Lodge_Idx) {
		this.saveList_Lodge_Idx = saveList_Lodge_Idx;
	}
	
}
