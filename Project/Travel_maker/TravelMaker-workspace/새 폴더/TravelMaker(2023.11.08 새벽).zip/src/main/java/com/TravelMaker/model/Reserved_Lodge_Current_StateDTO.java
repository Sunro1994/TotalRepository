package com.TravelMaker.model;

import java.util.Date;

public class Reserved_Lodge_Current_StateDTO {
	private int reserved_Lodge_Current_State_Idx;
	private String reserved_Lodge_Current_State_UserId;
	private int reserved_Lodge_Current_State_RoomIdx;
	private Date reserved_Lodge_Current_State_StartDate;
	private Date reserved_Lodge_Current_State_EndDate;
	public Date getReserved_Lodge_Current_State_StartDate() {
		return reserved_Lodge_Current_State_StartDate;
	}
	public void setReserved_Lodge_Current_State_StartDate(Date reserved_Lodge_Current_State_StartDate) {
		this.reserved_Lodge_Current_State_StartDate = reserved_Lodge_Current_State_StartDate;
	}
	public Date getReserved_Lodge_Current_State_EndDate() {
		return reserved_Lodge_Current_State_EndDate;
	}
	public void setReserved_Lodge_Current_State_EndDate(Date reserved_Lodge_Current_State_EndDate) {
		this.reserved_Lodge_Current_State_EndDate = reserved_Lodge_Current_State_EndDate;
	}
	public int getReserved_Lodge_Current_State_Idx() {
		return reserved_Lodge_Current_State_Idx;
	}
	public void setReserved_Lodge_Current_State_Idx(int reserved_Lodge_Current_State_Idx) {
		this.reserved_Lodge_Current_State_Idx = reserved_Lodge_Current_State_Idx;
	}
	public String getReserved_Lodge_Current_State_UserId() {
		return reserved_Lodge_Current_State_UserId;
	}
	public void setReserved_Lodge_Current_State_UserId(String reserved_Lodge_Current_State_UserId) {
		this.reserved_Lodge_Current_State_UserId = reserved_Lodge_Current_State_UserId;
	}
	public int getReserved_Lodge_Current_State_RoomIdx() {
		return reserved_Lodge_Current_State_RoomIdx;
	}
	public void setReserved_Lodge_Current_State_RoomIdx(int reserved_Lodge_Current_State_RoomIdx) {
		this.reserved_Lodge_Current_State_RoomIdx = reserved_Lodge_Current_State_RoomIdx;
	}
	
	
	
	
}