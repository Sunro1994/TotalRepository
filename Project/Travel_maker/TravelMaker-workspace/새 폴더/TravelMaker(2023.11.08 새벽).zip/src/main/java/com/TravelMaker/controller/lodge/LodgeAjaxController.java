package com.TravelMaker.controller.lodge;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.TravelMaker.model.LodgeDTO;
import com.TravelMaker.model.Lodge_Room_TypeDTO;
import com.TravelMaker.model.SaveListDTO;
import com.TravelMaker.model.TravelMaker_MemberDTO;
import com.TravelMaker.service.lodge.LodgeService;

@RestController
@RequestMapping("/lodge")
public class LodgeAjaxController {
	
	@Autowired LodgeService lodgeService;
	
	/*   필터 검색 결과 가져오는 메서드  */
	@PostMapping("/getSelectedList")
	public List<LodgeDTO> getList(@RequestBody LodgeDTO LodgeFilter ){
		HashMap<String, Object> map = new HashMap<String, Object>();
		List<String> Arealist = LodgeFilter.getAreaArr();
		List<String> Typelist = LodgeFilter.getTypeArr();
		String startDate = LodgeFilter.getStartDate();
		String endDate = LodgeFilter.getEndDate();
		
		map.put("startDate"	, startDate);
		map.put("endDate"	, endDate);
		map.put("Arealist",Arealist);
		map.put("Typelist",Typelist);
		
		
		List<LodgeDTO> list =  lodgeService.selectedList(map);
		
		
		
		
		return list;
		
	}
	
	/*   랜덤 결과 가져오는 메서드  */
	@PostMapping("/getRandomList")
	public List<LodgeDTO> getRandomList(){
		List<LodgeDTO> list = lodgeService.randomList();
		return list;
	}
	
	
	/*   숙소 검색 결과로 가져오는 메서드  */
	@PostMapping("/getSelectKeywordList")
	public List<LodgeDTO> getSelectKeywordList(String keyword) {
		List<LodgeDTO> list = lodgeService.selectKeyword(keyword);
		return list;
	}
	
	/*   숙소 세부 정보(객실) 필터로 가져오는 메서드  */
	@PostMapping("/getselectedRoom")
	public List<Lodge_Room_TypeDTO> getselectedRoom(@RequestBody Lodge_Room_TypeDTO roomFilter ){
		
		List<Lodge_Room_TypeDTO> list = lodgeService.selectedRoomList(roomFilter);
		
		
		
		return list;
		
	}
	
	/* 숙소  찜하는 메서드 */
	@GetMapping("/saveList")
	public  List<LodgeDTO> getSaveList(int lodge_idx,String userid, HttpSession session) {
		TravelMaker_MemberDTO user = (TravelMaker_MemberDTO) session.getAttribute("user");
		
		SaveListDTO save1 = new SaveListDTO();
		save1.setSaveList_Lodge_Idx(lodge_idx);
		save1.setSaveList_UserId(user.getTravelMaker_Member_UserId());
		
		int row = lodgeService.saveInsert(save1);
		
		
		SaveListDTO save = new SaveListDTO();
		save.setSaveList_UserId(user.getTravelMaker_Member_UserId());
		save.setSaveList_Lodge_Idx(lodge_idx);
		
		List<LodgeDTO > dto = lodgeService.selectSaveList(save);
		return dto;
	}
}
