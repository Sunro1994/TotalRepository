package com.TravelMaker.controller.admin;

import com.TravelMaker.model.Recommend_TravelDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.TravelMaker.model.LodgeDTO;
import com.TravelMaker.service.admin.AdminService;

@Controller
@RequestMapping("/Admin")
public class AdminController {
	
	@Autowired private AdminService adminService;
	
	// 관리자 페이지
	@GetMapping("/admin")
	public void admin() {}
	
	@GetMapping("/lodgeWrite")
	public void lodgeWrite() {}
	
	@PostMapping("/actionLodgeWrite")
	public String lodgeWrite(LodgeDTO dto) {
		int row = adminService.insertLodge(dto);
		System.out.println(row + "행이 추가되었습니다.");
		
		return "redirect:/Admin/admin";
	}

	@GetMapping("/recommendWrite")
	public void recommendWrite(){}

	@PostMapping("/recommendWrite")
	public String recommendWrite(Recommend_TravelDTO dto){
		int row = adminService.insertRecommend(dto);
		System.out.println(row + "행이 추가 되었습니다");

		return "redirect:/Admin/admin";
	}

}
