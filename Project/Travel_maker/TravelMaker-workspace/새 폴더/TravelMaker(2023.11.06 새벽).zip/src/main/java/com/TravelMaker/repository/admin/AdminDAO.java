package com.TravelMaker.repository.admin;

import com.TravelMaker.model.LodgeDTO;
import com.TravelMaker.model.Recommend_TravelDTO;

public interface AdminDAO {

	int insertLodge(LodgeDTO dto);


    int insertRecommend(Recommend_TravelDTO dto);
}
