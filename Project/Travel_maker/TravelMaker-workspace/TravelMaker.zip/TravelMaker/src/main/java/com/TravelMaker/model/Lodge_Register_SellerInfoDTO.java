package com.TravelMaker.model;

public class Lodge_Register_SellerInfoDTO {
	private String lodge_Register_SellerInfo_BusinessNum;
	private String lodge_Register_SellerInfo_Address;
	private String lodge_Register_SellerInfo_CeoName;
	private String lodge_Register_SellerInfo_Tel;
	private String lodge_Register_SellerInfo_Email;
	public String getLodge_Register_SellerInfo_BusinessNum() {
		return lodge_Register_SellerInfo_BusinessNum;
	}
	public void setLodge_Register_SellerInfo_BusinessNum(String lodge_Register_SellerInfo_BusinessNum) {
		this.lodge_Register_SellerInfo_BusinessNum = lodge_Register_SellerInfo_BusinessNum;
	}
	public String getLodge_Register_SellerInfo_Address() {
		return lodge_Register_SellerInfo_Address;
	}
	public void setLodge_Register_SellerInfo_Address(String lodge_Register_SellerInfo_Address) {
		this.lodge_Register_SellerInfo_Address = lodge_Register_SellerInfo_Address;
	}
	public String getLodge_Register_SellerInfo_CeoName() {
		return lodge_Register_SellerInfo_CeoName;
	}
	public void setLodge_Register_SellerInfo_CeoName(String lodge_Register_SellerInfo_CeoName) {
		this.lodge_Register_SellerInfo_CeoName = lodge_Register_SellerInfo_CeoName;
	}
	public String getLodge_Register_SellerInfo_Tel() {
		return lodge_Register_SellerInfo_Tel;
	}
	public void setLodge_Register_SellerInfo_Tel(String lodge_Register_SellerInfo_Tel) {
		this.lodge_Register_SellerInfo_Tel = lodge_Register_SellerInfo_Tel;
	}
	public String getLodge_Register_SellerInfo_Email() {
		return lodge_Register_SellerInfo_Email;
	}
	public void setLodge_Register_SellerInfo_Email(String lodge_Register_SellerInfo_Email) {
		this.lodge_Register_SellerInfo_Email = lodge_Register_SellerInfo_Email;
	}
	
	
	
}
