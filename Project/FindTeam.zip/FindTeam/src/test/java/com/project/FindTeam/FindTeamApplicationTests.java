package com.project.FindTeam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FindTeamApplicationTests {

	@Test
	void contextLoads() {
	}

}
