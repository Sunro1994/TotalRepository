package com.project.FindTeam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FindTeamApplication {

	public static void main(String[] args) {
		SpringApplication.run(FindTeamApplication.class, args);
	}

}
