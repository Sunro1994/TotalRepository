package com.erp.ErpMaster;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ErpMasterApplication {

	public static void main(String[] args) {
		SpringApplication.run(ErpMasterApplication.class, args);
	}

}
