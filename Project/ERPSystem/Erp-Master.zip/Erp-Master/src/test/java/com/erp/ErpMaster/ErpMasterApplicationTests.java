package com.erp.ErpMaster;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ErpMasterApplicationTests {

	@Test
	void contextLoads() {
	}

}
