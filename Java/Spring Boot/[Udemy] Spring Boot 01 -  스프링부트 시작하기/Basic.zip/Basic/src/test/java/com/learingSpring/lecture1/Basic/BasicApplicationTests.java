package com.learingSpring.lecture1.Basic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BasicApplicationTests {

	@Test
	void contextLoads() {
	}

}
