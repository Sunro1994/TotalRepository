package com.eazybytes.springsecurirtybasic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringsecurirtybasicApplicationTests {

	@Test
	void contextLoads() {
	}

}
