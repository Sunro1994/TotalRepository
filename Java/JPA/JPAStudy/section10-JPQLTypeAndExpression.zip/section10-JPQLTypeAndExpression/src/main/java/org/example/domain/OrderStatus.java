package org.example.domain;


public enum OrderStatus {
    Ready, Comp
}
