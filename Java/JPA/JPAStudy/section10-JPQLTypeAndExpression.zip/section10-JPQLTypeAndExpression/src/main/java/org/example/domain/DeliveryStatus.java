package org.example.domain;

public enum DeliveryStatus {
    Complete, Shpping,ready
}
