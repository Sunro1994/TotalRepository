package org.example.domain;

public enum MemberType {
    ADMIN,USER
}
